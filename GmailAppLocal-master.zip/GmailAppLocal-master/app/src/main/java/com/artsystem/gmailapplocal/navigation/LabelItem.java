package com.artsystem.gmailapplocal.navigation;

public class LabelItem {

    private String label;

    public LabelItem(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
